let a=9;
let b=2*Math.sin(a)-3*Math.cos(a);
