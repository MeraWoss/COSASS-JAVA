function cargarPagina()
{
	document.getElementsByTagName("body")[0].innerHTML="Texto en el body";
}